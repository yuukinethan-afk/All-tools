NINGEN METHODZ v1.8.0
Ekstensi Chrome/Edge/Kiwi/Quetta untuk TikTok Studio. Video MP4 di-patch lokal di browser
sebelum diunggah, supaya TikTok tidak mengompres ulang. Tidak ada data yang dikirim keluar.

PASANG
1. Ekstrak ZIP.
2. Buka chrome://extensions, aktifkan Developer mode.
3. Load unpacked, pilih folder hasil ekstrak.
   (Android: Kiwi/Quetta/Lemur -> Developer mode -> pasang dari .zip)

PAKAI
1. Buka popup, tekan "UPLOAD METHOD NINGEN" (membuka TikTok Studio, mode desktop otomatis di HP).
2. Di halaman upload, pilih video lewat kartu Ningen. Video di-patch otomatis lalu diteruskan ke TikTok.
3. Isi caption seperti biasa. Watermark caption (default "✦ Upload Method by Ningen") SELALU ditambahkan
   di akhir caption dan tidak bisa dimatikan siapa pun — hanya teksnya yang bisa diganti di Setting.

PENGATURAN (popup -> Setting)
- Teks watermark caption (wajib aktif, teks bisa diganti)
- Rapikan payload posting
- Flag kualitas tinggi
- Mode agresif (filler audio, menimpa 4 sampel audio terakhir)
- Log diagnostik (cetak field yang diubah ke console)
- Tag metadata video (default @asepfrimawan)

MODE ADMIN (opsional)
Buat kode lewat admin.html -> panel "Kode Mode Admin (Ningen)". Tempel kodenya di popup Setting -> Kode admin.
Kode diverifikasi ke server berikut nomor versi ekstensi yang terpasang: kode HANYA berlaku bila ekstensi
sudah di versi terbaru yang diset lewat admin.html. Ekstensi versi lama otomatis ditolak walau kodenya benar,
jadi mode admin tidak bisa dipakai untuk "mengunci" bypass di instalasi yang ketinggalan update. Instalasi yang
lolos cek ini SELALU aktif walau saklar jarak jauh dimatikan untuk pengguna lain. Kode dicek ke server tiap
±20 detik (bukan dicocokkan di dalam ekstensi), jadi bisa kamu cabut kapan saja dari admin.html tanpa update
ekstensi. Kalau server tak terjangkau, status terakhir yang diketahui tetap dipakai sementara.

SAKLAR JARAK JAUH (opsional)
Ekstensi mengecek /api/ningen-kill di web tools kamu tiap ±20 detik. Kalau dimatikan dari admin, SEMUA
fitur patch (MP4, payload posting, watermark caption) nonaktif di semua browser yang terpasang; video
dikirim apa adanya seperti tanpa ekstensi. Kalau server tak terjangkau, ekstensi tetap aktif (default ON),
jadi tidak terkunci kalau servernya sedang mati. Di popup, status ini ditampilkan sebagai pop-up card
di tengah layar (bukan teks kecil), supaya langsung kelihatan kalau sedang nonaktif dari server.

KONTAK DEVELOPER (popup)
- TikTok: @asepfrimawan
- WhatsApp Channel: https://whatsapp.com/channel/0029VbBNSiJJ93watcQasK2F

VIDEO LATAR
- body.mp4     : latar seluruh halaman popup & tab app
- bglaunch.mp4 : latar tombol Upload Method Ningen (popup)
- bg.mp4       : latar kartu di halaman upload TikTok Studio
- compare.mp4  : opsional, bagian "lihat perbedaannya" di tab app
Tanpa file, latar polos (warna dasar) dipakai sebagai gantinya.

FOTO PROFIL
- brand.jpg : ikon profil di pojok kiri atas popup/app (ganti file ini untuk ganti ikon).

CATATAN
- Hanya MP4/MOV (H.264/HEVC). Fragmented MP4 dan file di atas 4 GB tidak diproses; file asli dikirim apa adanya.
- Hasil di TikTok tidak bisa dijamin; platform dapat mengubah perilakunya sewaktu-waktu.
