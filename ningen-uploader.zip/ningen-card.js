/*
 * Ningen card (content script, isolated world).
 * - Membungkus area upload TikTok Studio dengan overlay penuh (kartu Ningen di tengah).
 *   Elemen asli TikTok disembunyikan dengan clip-path (bukan display:none) supaya React tetap hidup.
 * - Mencegat video MP4/MOV yang dipilih/di-drop, patch lokal, lalu meneruskan ke input upload TikTok.
 * - Klik overlay memicu tombol "Pilih video" asli TikTok agar state internalnya normal.
 * - Jika zona tidak terdeteksi, kartu tampil melayang di pojok kanan bawah.
 * - Jika patch gagal, video TIDAK dikirim otomatis; ada tombol "Kirim asli".
 */
if (typeof chrome === 'undefined' && typeof browser !== 'undefined') { try { globalThis.chrome = browser; } catch (e) { /* noop */ } }
(() => {
  'use strict';
  if (window.__ningenCard) return;
  window.__ningenCard = true;

  const STR = {
    id: {
      prompt: 'MASUKKAN VIDEO DI SINI', pick: 'Pilih Video', change: 'Ganti Video', raw: 'Kirim asli',
      ready: 'Aktif', reading: 'Membaca…', analyzing: 'Analisis…', patching: 'Patch…', preparing: 'Menyiapkan…',
      review: 'Cek data video', done: 'Selesai', failed: 'Gagal',
      res: 'Resolusi', fps: 'FPS', size: 'Ukuran', bitrate: 'Bitrate', codec: 'Codec',
      busy: 'Masih memproses video…', fail: 'Patch gagal, video belum dikirim: ', noinput: 'Input upload TikTok tidak ditemukan',
      hooked: 'Ningen: request posting diubah', continue: 'Lanjutkan Upload',
      outdated: 'Ekstensi Ningen kamu versi lama, update dulu ke versi terbaru. Video dikirim apa adanya ke TikTok sampai kamu update.'
    },
    en: {
      prompt: 'DROP VIDEO IN HERE', pick: 'Select Video', change: 'Change Video', raw: 'Send original',
      ready: 'Active', reading: 'Reading…', analyzing: 'Analyzing…', patching: 'Patching…', preparing: 'Preparing…',
      review: 'Check video data', done: 'Done', failed: 'Failed',
      res: 'Resolution', fps: 'FPS', size: 'Size', bitrate: 'Bitrate', codec: 'Codec',
      busy: 'Still processing a video…', fail: 'Patch failed, video not sent: ', noinput: 'TikTok upload input not found',
      hooked: 'Ningen: post request modified', continue: 'Continue Upload',
      outdated: 'Your Ningen extension is outdated, please update to the latest version. Videos are sent as-is to TikTok until you update.'
    }
  };

  // Tidak ada lagi saklar lokal aktif/non-aktif: ekstensi selalu aktif kecuali dimatikan dari server (remoteOn)
  // atau kode admin kebal (admin). "outdated" (versi ekstensi di bawah versi terbaru yang diset admin)
  // MENGUNCI TOTAL untuk SEMUA orang, termasuk yang punya kode admin — tidak ada yang kebal dari ini.
  const st = { tail: true, hook: true, quality: true, debug: false, caption: true, captionText: '✦ Upload Method by Ningen', tag: '@asepfrimawan', lang: /^id/i.test(navigator.language || '') ? 'id' : 'en', remoteOn: true, remoteMsg: '', admin: false, outdated: false };
  const active = () => !st.outdated && (st.remoteOn || st.admin);
  // Bandingkan versi semver sederhana "1.8.0" vs "1.7.4". Return true kalau `a` lebih lama dari `b`.
  function versionBehind(a, b) {
    const pa = String(a || '0').split('.').map((n) => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const x = pa[i] || 0, y = pb[i] || 0;
      if (x < y) return true;
      if (x > y) return false;
    }
    return false;
  }
  let busy = false, passThrough = false, shown = 0, toastTimer = 0, pending = null, reviewPending = null, nativeBtn = null, decorateTimer = 0;
  const S = (k) => (STR[st.lang] && STR[st.lang][k]) || STR.en[k] || k;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ---------- pengaturan (dari popup) ---------- */
  const store = (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) || null;
  const DEFAULTS = { ningenLang: null, ningenTail: true, ningenHook: true, ningenQuality: true, ningenTag: '@asepfrimawan', ningenDebug: false, ningenCaptionText: '✦ Upload Method by Ningen', ningenAdminKey: '' };
  const ADMIN_VERIFY_URL = 'https://alltoolsningen.vercel.app/api/ningen-admin';
  const ADMIN_TTL = 20 * 1000; // cek tiap 20 detik, biar saklar cepat kerasa
  const EXT_VERSION = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '0.0.0';
  function broadcastAdmin() {
    schedule();
    try { window.postMessage({ source: 'NINGEN', type: 'SETTINGS', settings: { normalize: st.hook && active(), quality: st.quality && active(), debug: st.debug, caption: active(), captionText: st.captionText } }, '*'); } catch (_) { /* noop */ }
  }
  // Kode admin diverifikasi ke server (bukan dicocokkan lokal), jadi bisa dicabut admin kapan saja tanpa update ekstensi.
  // Server juga mewajibkan ekstensi berada di versi terbaru: kode admin tidak berlaku di versi lama/usang.
  function checkAdminKeyRemote(key) {
    key = (key || '').trim();
    if (!key) { st.admin = false; broadcastAdmin(); return; }
    if (store) {
      try {
        store.get({ ningenAdminCache: null }, (r) => {
          const c = r && r.ningenAdminCache;
          if (c && c.key === key && c.version === EXT_VERSION) { st.admin = !!c.ok; broadcastAdmin(); }
          if (c && c.key === key && c.version === EXT_VERSION && Date.now() - (c.ts || 0) < ADMIN_TTL) return; // masih segar
          verifyAdminKey(key);
        });
      } catch (_) { verifyAdminKey(key); }
    } else verifyAdminKey(key);
  }
  function verifyAdminKey(key) {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 5000);
      fetch(ADMIN_VERIFY_URL, {
        method: 'POST', cache: 'no-store', signal: ctl.signal, credentials: 'omit',
        headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'verify', key, version: EXT_VERSION }),
      })
        .then((res) => (res.ok ? res.json() : null))
        .then((d) => {
          clearTimeout(to);
          if (!d || typeof d.ok !== 'boolean') return; // gagal baca: pakai status terakhir yang diketahui
          st.admin = d.ok;
          broadcastAdmin();
          if (store) try { store.set({ ningenAdminCache: { key, version: EXT_VERSION, ok: d.ok, ts: Date.now() } }); } catch (_) { /* noop */ }
        })
        .catch(() => { /* offline/diblokir: biarkan status terakhir tetap berlaku */ });
    } catch (_) { /* noop */ }
  }
  function applySettings(r) {
    if (r.ningenLang) st.lang = r.ningenLang;
    st.tail = r.ningenTail !== false;
    st.hook = r.ningenHook !== false;
    st.quality = r.ningenQuality !== false;
    st.debug = r.ningenDebug === true;
    st.caption = true; // watermark caption tidak bisa dinonaktifkan siapa pun
    st.captionText = (typeof r.ningenCaptionText === 'string' && r.ningenCaptionText.trim()) || '✦ Upload Method by Ningen';
    st.tag = (typeof r.ningenTag === 'string' && r.ningenTag.trim()) || '@asepfrimawan';
    checkAdminKeyRemote(typeof r.ningenAdminKey === 'string' ? r.ningenAdminKey : '');
    try { window.postMessage({ source: 'NINGEN', type: 'SETTINGS', settings: { normalize: st.hook && active(), quality: st.quality && active(), debug: st.debug, caption: active(), captionText: st.captionText } }, '*'); } catch (_) { /* noop */ }
  }
  function loadSettings() {
    if (!store) return;
    try { store.get(DEFAULTS, (r) => { applySettings(r || DEFAULTS); relabel(); schedule(); }); } catch (_) { /* noop */ }
  }
  loadSettings();
  try { chrome.storage.onChanged.addListener((_, area) => { if (area === 'local') loadSettings(); }); } catch (_) { /* noop */ }

  /* ---------- saklar jarak jauh (opsional): /api/ningen-kill di web tools milik user sendiri ---------- */
  const REMOTE_URL = 'https://alltoolsningen.vercel.app/api/ningen-kill';
  const REMOTE_TTL = 20 * 1000; // cache 20 detik: cek server ringan (cuma baca status), tapi saklar cepat kerasa
  let remoteNotified = 0;
  function setRemote(on, msg, latestVersion) {
    const was = active();
    st.remoteOn = on !== false;
    st.remoteMsg = (typeof msg === 'string' && msg.trim()) || '';
    const lv = (typeof latestVersion === 'string' && latestVersion.trim()) || '';
    st.outdated = !!lv && versionBehind(EXT_VERSION, lv);
    try { window.postMessage({ source: 'NINGEN', type: 'SETTINGS', settings: { normalize: st.hook && active(), quality: st.quality && active(), debug: st.debug, caption: active(), captionText: st.captionText } }, '*'); } catch (_) { /* noop */ }
    if (was && !active() && Date.now() - remoteNotified > 60000) {
      remoteNotified = Date.now();
      if (st.outdated) toast(S('outdated'));
      else toast('Ningen dinonaktifkan sementara' + (st.remoteMsg ? ': ' + st.remoteMsg : '.') + ' Video dikirim apa adanya ke TikTok.');
    }
    schedule();
  }
  function checkRemote() {
    if (store) {
      try {
        store.get({ ningenRemoteCache: null }, (r) => {
          const c = r && r.ningenRemoteCache;
          if (c && typeof c.on === 'boolean') setRemote(c.on, c.msg, c.latestVersion);
          if (c && Date.now() - (c.ts || 0) < REMOTE_TTL) return; // cache masih segar, tidak perlu fetch
          fetchRemote();
        });
      } catch (_) { fetchRemote(); }
    } else fetchRemote();
  }
  function fetchRemote() {
    try {
      const ctl = new AbortController();
      const to = setTimeout(() => ctl.abort(), 5000);
      fetch(REMOTE_URL, { cache: 'no-store', signal: ctl.signal, credentials: 'omit' })
        .then((res) => (res.ok ? res.json() : null))
        .then((d) => {
          clearTimeout(to);
          if (!d || typeof d !== 'object') return; // gagal baca: pakai cache/default (fail-open, tidak mengunci kalau server mati)
          setRemote(d.on, d.msg, d.latestVersion);
          if (store) try { store.set({ ningenRemoteCache: { on: d.on !== false, msg: d.msg, latestVersion: d.latestVersion, ts: Date.now() } }); } catch (_) { /* noop */ }
        })
        .catch(() => { /* offline/diblokir: biarkan nilai cache/default (ON) tetap berlaku */ });
    } catch (_) { /* noop */ }
  }
  checkRemote();
  setInterval(checkRemote, REMOTE_TTL);

  /* ---------- util ---------- */
  const isVideoInput = (el) => el && el.tagName === 'INPUT' && el.type === 'file' && (!el.accept || /video|mp4|mov/i.test(el.accept));
  const findInput = () => Array.from(document.querySelectorAll('input[type="file"]')).find(isVideoInput) || null;
  const isPatchable = (f) => !!f && (/^video\/(mp4|quicktime)$/i.test(f.type) || /\.(mp4|mov|m4v)$/i.test(f.name || ''));
  const isEditorPage = () => !!document.querySelector('.public-DraftEditor-content, [data-contents="true"], [contenteditable="true"][role="combobox"], [class*="caption-editor" i]');
  const findNativeBtn = () => Array.from(document.querySelectorAll('button')).find((b) =>
    /pilih video|select video|choose video|unggah video|upload video/i.test((b.textContent || '').trim()) && !b.closest('.ngn-overlay, .ngn-card')) || null;

  function dashed(el) {
    try { const s = getComputedStyle(el); return ['Top', 'Right', 'Bottom', 'Left'].some((k) => s['border' + k + 'Style'] === 'dashed'); }
    catch (_) { return false; }
  }
  // naik dari tombol/input sampai ketemu kotak dropzone (border putus-putus, atau kotak besar pertama)
  function findZone(start) {
    let cur = start, fallback = null;
    for (let i = 0; i < 14 && cur && cur !== document.body && cur !== document.documentElement; i++, cur = cur.parentElement) {
      if (dashed(cur)) return cur;
      const r = cur.getBoundingClientRect();
      if (!fallback && r.width >= 240 && r.height >= 140 && r.height < 900 && !cur.querySelector('header, nav, [role="tablist"]')) fallback = cur;
    }
    return fallback;
  }

  function toast(msg) {
    let el = document.querySelector('.ngn-toast');
    if (!el) { el = document.createElement('div'); el.className = 'ngn-toast'; (document.body || document.documentElement).appendChild(el); }
    el.textContent = msg;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.remove(), 3800);
  }

  /* ---------- kartu ---------- */
  const cardEl = () => document.querySelector('.ngn-card');
  const q = (c, s) => c.querySelector(s);
  const cardHtml = (float) =>
    '<div class="ngn-card' + (float ? ' ngn-float' : '') + '" data-state="ready" data-btn="pick">' +
    '<div class="ngn-head"><b>NINGEN<i class="ngn-cursor"></i></b><span class="ngn-state"></span></div>' +
    '<div class="ngn-chips"><i data-k="avc">H.264/AVC</i><i data-k="hevc">H.265/HEVC</i><i data-k="mp4">MP4</i><i data-k="mov">MOV</i></div>' +
    '<div class="ngn-prompt" data-i="prompt"></div>' +
    '<button type="button" class="ngn-btn"></button>' +
    '<button type="button" class="ngn-raw" data-i="raw" hidden></button>' +
    '<div class="ngn-file"></div>' +
    '<div class="ngn-grid">' +
    ['res', 'fps', 'size', 'bitrate'].map((k) => '<div><span data-i="' + k + '"></span><b data-f="' + k + '">—</b></div>').join('') +
    '<div class="ngn-wide"><span data-i="codec"></span><b data-f="codec">—</b></div></div>' +
    '<div class="ngn-prog"><div class="ngn-track"><i></i></div><span class="ngn-pct">0%</span></div>' +
    '<button type="button" class="ngn-continue" data-i="continue" hidden></button>' +
    '</div>';

  function wireCard(c) {
    q(c, '.ngn-btn').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); if (!busy) openPicker(); });
    q(c, '.ngn-raw').addEventListener('click', (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!pending) return;
      const { file, input } = pending; pending = null;
      q(c, '.ngn-raw').hidden = true;
      if (deliver(input, file)) { c.classList.remove('failed'); setState(c, 'done'); }
    });
    q(c, '.ngn-continue').addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); confirmDeliver(c); });
  }
  function relabel() {
    const c = cardEl();
    if (!c) return;
    c.querySelectorAll('[data-i]').forEach((n) => { n.textContent = S(n.dataset.i); });
    q(c, '.ngn-state').textContent = S(c.dataset.state || 'ready');
    q(c, '.ngn-btn').textContent = S(c.dataset.btn || 'pick');
  }
  // setelah video dipatch, ditahan dulu di kartu (tidak langsung diteruskan ke TikTok) supaya
  // pengguna sempat melihat ukuran/resolusi/fps-nya; baru lanjut kalau tombol "Lanjutkan" ditekan.
  function confirmDeliver(c) {
    if (!reviewPending) return;
    const { input, out } = reviewPending; reviewPending = null;
    q(c, '.ngn-continue').hidden = true;
    if (deliver(input, out)) {
      setState(c, 'done');
      setTimeout(() => { if (isEditorPage()) removeAll(); }, 800);
    } else {
      toast(S('noinput'));
    }
  }
  function setState(c, key) { if (!c) return; c.dataset.state = key; q(c, '.ngn-state').textContent = S(key); }
  function paint(c, n) { shown = n; if (!c) return; q(c, '.ngn-pct').textContent = n + '%'; q(c, '.ngn-track i').style.width = n + '%'; }
  async function climb(c, to) { if (!c) { shown = to; return; } while (shown < to) { paint(c, shown + 1); await sleep(to - shown > 25 ? 5 : 11); } }
  const field = (c, k, v) => { if (c) q(c, '[data-f="' + k + '"]').textContent = v; };
  function markChips(c, meta, file) {
    if (!c) return;
    const ext = /\.mov$/i.test(file.name) ? 'mov' : 'mp4';
    c.querySelectorAll('.ngn-chips i').forEach((n) => n.classList.toggle('on', !!meta && (n.dataset.k === meta.codecKey || n.dataset.k === ext)));
  }
  function showInfo(c, file, meta) {
    if (!c) return;
    const F = globalThis.NingenMeta.fmt;
    q(c, '.ngn-file').textContent = file.name;
    field(c, 'res', F.res(meta)); field(c, 'fps', F.fps(meta)); field(c, 'size', F.size(file.size));
    field(c, 'bitrate', F.bitrate(meta)); field(c, 'codec', meta ? meta.codec : '—');
    c.classList.add('has-file');
  }

  /* ---------- picker & pengiriman file ---------- */
  function openPicker() {
    // pakai tombol asli TikTok bila ada, supaya state internalnya terbentuk normal
    if (nativeBtn && nativeBtn.isConnected) { nativeBtn.click(); return; }
    const i = findInput();
    if (i) i.click();
  }
  function deliver(input, file) {
    const target = input && input.isConnected ? input : findInput();
    if (!target) { toast(S('noinput')); return false; }
    const dt = new DataTransfer();
    dt.items.add(file);
    target.files = dt.files;
    passThrough = true;
    try {
      target.dispatchEvent(new Event('input', { bubbles: true }));
      target.dispatchEvent(new Event('change', { bubbles: true }));
    } finally { passThrough = false; }
    return true;
  }

  async function run(file, input) {
    if (busy) { toast(S('busy')); return; }
    busy = true; pending = null; reviewPending = null;
    const c = cardEl();
    if (c) {
      c.classList.add('busy', 'has-file'); c.classList.remove('failed');
      q(c, '.ngn-raw').hidden = true;
      q(c, '.ngn-continue').hidden = true;
      q(c, '.ngn-file').textContent = file.name;
      ['res', 'fps', 'bitrate', 'codec'].forEach((k) => field(c, k, '…'));
      field(c, 'size', globalThis.NingenMeta.fmt.size(file.size));
      markChips(c, null, file);
    }
    paint(c, 0); setState(c, 'reading');

    let note = '', out = null;
    try {
      await climb(c, 15);
      setState(c, 'analyzing');
      let meta = null;
      try { meta = globalThis.NingenMeta.parse(await globalThis.NingenCore.readMoov(file)); } catch (_) { /* info opsional */ }
      showInfo(c, file, meta); markChips(c, meta, file);
      await climb(c, 45);

      setState(c, 'patching');
      const res = await globalThis.NingenCore.patch(file, { audioTail: st.tail, tag: st.tag });
      await climb(c, 85);

      setState(c, 'preparing');
      out = new File([res.blob], file.name, { type: 'video/mp4', lastModified: Date.now() });
      field(c, 'size', globalThis.NingenMeta.fmt.size(out.size)); // ukuran akhir setelah di-patch, bukan ukuran sebelum patch
      await climb(c, 100);
    } catch (err) {
      note = S('fail') + (err && err.message ? err.message : err);
      pending = { file, input };
      try { if (input) input.value = ''; } catch (_) { /* noop */ }
    }

    const c2 = cardEl() || c;
    if (c2) c2.classList.toggle('failed', !!note);
    busy = false;
    if (note) {
      // patch gagal: tawarkan kirim video asli apa adanya (tidak ada yang ditahan buat direview)
      paint(c2, 0); toast(note); if (c2 && pending) q(c2, '.ngn-raw').hidden = false;
      setState(c2, 'failed');
      if (c2) { c2.classList.remove('busy'); c2.dataset.btn = 'change'; q(c2, '.ngn-btn').textContent = S('change'); }
      return;
    }
    // berhasil di-patch: TAHAN dulu di sini, jangan langsung diteruskan ke TikTok, supaya pengguna
    // sempat melihat ukuran/resolusi/fps/codec-nya dulu. Baru lanjut saat tombol "Lanjutkan" ditekan.
    reviewPending = { input, out };
    setState(c2, 'review');
    if (c2) {
      c2.classList.remove('busy');
      c2.dataset.btn = 'change'; q(c2, '.ngn-btn').textContent = S('change');
      q(c2, '.ngn-continue').hidden = false;
    }
  }

  /* ---------- pencegat: pilih file & drag-drop ---------- */
  function onPick(e) {
    const t = e.target;
    if (!active() || passThrough || !isVideoInput(t) || !t.files || !t.files.length) return;
    if (!isPatchable(t.files[0])) return; // bukan MP4/MOV: biarkan lewat apa adanya
    e.stopImmediatePropagation();
    if (e.type === 'change') run(t.files[0], t);
  }
  window.addEventListener('change', onPick, true);
  window.addEventListener('input', onPick, true);
  window.addEventListener('drop', (e) => {
    if (!active() || passThrough) return;
    const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (!f || !isPatchable(f)) return;
    const input = findInput();
    if (!input) return;
    e.preventDefault(); e.stopImmediatePropagation();
    document.querySelectorAll('.ngn-zone').forEach((z) => z.classList.remove('ngn-drag'));
    run(f, input);
  }, true);

  // verifikasi: hook memberi tahu saat payload posting benar-benar diubah
  let lastPatchedToast = 0;
  window.addEventListener('message', (e) => {
    if (e.source !== window) return;
    const d = e.data;
    if (!d || d.source !== 'NINGEN_HOOK' || d.type !== 'PATCHED') return;
    const now = Date.now();
    if (now - lastPatchedToast < 4000) return;
    lastPatchedToast = now;
    toast(S('hooked') + ' (' + d.count + ' field)');
  });

  /* ---------- pasang / lepas overlay ---------- */
  function removeAll() {
    document.querySelectorAll('.ngn-overlay').forEach((n) => n.remove());
    document.querySelectorAll('.ngn-card.ngn-float').forEach((n) => n.remove());
    document.querySelectorAll('.ngn-zone').forEach((n) => n.classList.remove('ngn-zone', 'ngn-drag'));
  }

  function mountOverlay(zone) {
    if (getComputedStyle(zone).position === 'static') zone.style.position = 'relative';
    zone.classList.add('ngn-zone');

    let bgUrl = '';
    try { bgUrl = chrome.runtime.getURL('bg.mp4'); } catch (_) { /* noop */ }
    const ov = document.createElement('div');
    ov.className = 'ngn-overlay';
    ov.innerHTML = '<div class="ngn-bgfx"></div>' +
      (bgUrl ? '<video class="ngn-bgvideo" src="' + bgUrl + '" autoplay muted loop playsinline webkit-playsinline preload="auto"></video>' : '') +
      '<div class="ngn-bgdim"></div>' + cardHtml(false);
    const vid = ov.querySelector('.ngn-bgvideo');
    if (vid) {
      vid.addEventListener('error', () => vid.remove());
      vid.addEventListener('loadeddata', () => { ov.classList.add('has-video'); const p = vid.play(); if (p && p.catch) p.catch(() => {}); });
    }
    wireCard(ov.querySelector('.ngn-card'));
    // klik kita tidak boleh ikut sampai ke handler zona TikTok (bisa terbuka dua kali)
    ov.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); if (!busy) openPicker(); });
    ov.addEventListener('dragenter', () => zone.classList.add('ngn-drag'));
    ov.addEventListener('dragover', (e) => e.preventDefault());
    ov.addEventListener('dragleave', (e) => { if (!ov.contains(e.relatedTarget)) zone.classList.remove('ngn-drag'); });
    zone.appendChild(ov);
    relabel();
  }

  function mountFloat() {
    const host = document.body || document.documentElement;
    const wrap = document.createElement('div');
    wrap.innerHTML = cardHtml(true);
    const c = wrap.firstChild;
    wireCard(c);
    host.appendChild(c);
    relabel();
  }

  function decorate() {
    if (!active() || isEditorPage()) { if (!busy) removeAll(); return; }
    if (document.querySelector('.ngn-overlay')) return;
    const input = findInput();
    const btn = findNativeBtn();
    const start = (btn && btn.parentElement) || (input && input.parentElement);
    if (!start) { if (!busy) removeAll(); return; }
    nativeBtn = btn;
    const zone = findZone(start);
    if (zone) {
      document.querySelectorAll('.ngn-card.ngn-float').forEach((n) => n.remove());
      mountOverlay(zone);
      return;
    }
    if (input && !document.querySelector('.ngn-card.ngn-float') && window.innerWidth >= 320 && window.innerHeight >= 240) mountFloat();
  }

  function schedule() { clearTimeout(decorateTimer); decorateTimer = setTimeout(() => { try { decorate(); } catch (_) { /* noop */ } }, 200); }
  new MutationObserver(schedule).observe(document, { childList: true, subtree: true });
  schedule();
})();
