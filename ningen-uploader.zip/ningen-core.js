/*
 * Ningen core: MP4 patcher berbasis Blob (tanpa menyalin mdat ke memori).
 *
 * Yang dilakukan:
 *  1. Tata ulang kontainer ke layout "faststart": ftyp, moov, free, mdat.
 *  2. Nolkan timestamp pembuatan (mvhd/tkhd/mdhd) dan compressorname video.
 *  3. Skala ulang timescale film ke 1000 (mvhd, tkhd, elst ikut diskalakan).
 *  4. Geser semua offset chunk (stco/co64) sebesar selisih posisi mdat.
 *  5. Buang meta tingkat-moov, pertahankan udta asli, lalu tambah satu udta berisi tag (default "Ningen").
 *  6. (opsional) timpa beberapa sampel audio terakhir dengan filler.
 * Sampel video tidak pernah disentuh.
 */
(function (g) {
  'use strict';

  const CONTAINERS = new Set(['moov', 'trak', 'mdia', 'minf', 'stbl', 'edts']);
  const TAG_TEXT = '@asepfrimawan';
  const TAIL_COUNT = 4;
  const MAX_MOOV = 256 * 1024 * 1024;
  const TAIL_FILLER = Uint8Array.from([
    0xa0, 0x98, 0x00, 0x40, 0x01, 0x28, 0x00, 0x64, 0x00, 0x00, 0x03, 0x50, 0x00, 0x00, 0x38, 0x00
  ]);

  /* ---------- byte helpers ---------- */
  const u32 = (b, o) => ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
  const u64 = (b, o) => u32(b, o) * 4294967296 + u32(b, o + 4);
  const w32 = (b, o, v) => { b[o] = v >>> 24; b[o + 1] = v >>> 16; b[o + 2] = v >>> 8; b[o + 3] = v; };
  const w64 = (b, o, v) => { w32(b, o, Math.floor(v / 4294967296)); w32(b, o + 4, v >>> 0); };
  const tag4 = (b, o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);

  function cat(parts) {
    let n = 0;
    for (const p of parts) n += p.length;
    const out = new Uint8Array(n);
    let o = 0;
    for (const p of parts) { out.set(p, o); o += p.length; }
    return out;
  }
  function mk(type, payload) {
    const out = new Uint8Array(8 + payload.length);
    w32(out, 0, out.length);
    for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
    out.set(payload, 8);
    return out;
  }

  /* ---------- top-level scan (Blob) ---------- */
  async function scanTop(file) {
    const out = [];
    let o = 0;
    while (o + 8 <= file.size) {
      const h = new Uint8Array(await file.slice(o, Math.min(o + 16, file.size)).arrayBuffer());
      let size = u32(h, 0), hdr = 8;
      const type = tag4(h, 4);
      if (size === 1) {
        if (h.length < 16) throw new Error('Header ' + type + ' terpotong.');
        size = u64(h, 8); hdr = 16;
      } else if (size === 0) size = file.size - o;
      if (size < hdr || o + size > file.size) throw new Error('Struktur MP4 rusak pada box ' + type + '.');
      out.push({ type, offset: o, size, hdr, end: o + size });
      o += size;
    }
    return out;
  }

  /* ---------- moov tree ---------- */
  function parseTree(b, start, end) {
    const nodes = [];
    let o = start;
    while (o + 8 <= end) {
      let size = u32(b, o), hdr = 8;
      const type = tag4(b, o + 4);
      if (size === 1) { size = u64(b, o + 8); hdr = 16; }
      else if (size === 0) size = end - o;
      if (size < hdr || o + size > end) throw new Error('Box ' + type + ' di dalam moov rusak.');
      const node = { type, raw: b.slice(o, o + size), kids: null };
      if (CONTAINERS.has(type)) node.kids = parseTree(b, o + hdr, o + size);
      nodes.push(node);
      o += size;
    }
    return nodes;
  }
  const kid = (n, t) => (n && n.kids ? n.kids.find((k) => k.type === t) || null : null);
  const dig = (n, ts) => { let c = n; for (const t of ts) { c = kid(c, t); if (!c) return null; } return c; };
  const pstart = (leaf) => (u32(leaf.raw, 0) === 1 ? 16 : 8);
  const traks = (moov) => moov.kids.filter((k) => k.type === 'trak');
  function ser(n) { return n.kids ? mk(n.type, cat(n.kids.map(ser))) : n.raw; }
  function handler(trak) {
    const h = dig(trak, ['mdia', 'hdlr']);
    return h ? tag4(h.raw, pstart(h) + 8) : '';
  }

  /* ---------- header edits ---------- */
  function zeroTimes(n) {
    if (n.type === 'mvhd' || n.type === 'tkhd' || n.type === 'mdhd') {
      const p = pstart(n), v = n.raw[p];
      if (v === 1) { w64(n.raw, p + 4, 0); w64(n.raw, p + 12, 0); }
      else { w32(n.raw, p + 4, 0); w32(n.raw, p + 8, 0); }
      return;
    }
    if (n.kids) n.kids.forEach(zeroTimes);
  }

  function zeroCompressorName(moov) {
    for (const trak of traks(moov)) {
      if (handler(trak) !== 'vide') continue;
      const stsd = dig(trak, ['mdia', 'minf', 'stbl', 'stsd']);
      if (!stsd) continue;
      // fullbox(4) + entry_count(4) + entry header(8) + 6+2+16+2+2+4+4+4+2 = 42 -> compressorname[32]
      const at = pstart(stsd) + 8 + 8 + 42;
      if (at + 32 > stsd.raw.length) continue;
      stsd.raw.fill(0, at, at + 32);
    }
  }

  function rescaleMovie(moov, newScale) {
    const mvhd = kid(moov, 'mvhd');
    if (!mvhd) throw new Error('mvhd tidak ditemukan.');
    const p = pstart(mvhd), v = mvhd.raw[p];
    const tsAt = v === 1 ? p + 20 : p + 12;
    const durAt = v === 1 ? p + 24 : p + 16;
    const oldScale = u32(mvhd.raw, tsAt);
    if (!oldScale || oldScale === newScale) return;
    const ratio = newScale / oldScale;
    w32(mvhd.raw, tsAt, newScale);
    if (v === 1) w64(mvhd.raw, durAt, Math.round(u64(mvhd.raw, durAt) * ratio));
    else w32(mvhd.raw, durAt, Math.round(u32(mvhd.raw, durAt) * ratio));

    for (const trak of traks(moov)) {
      const tkhd = kid(trak, 'tkhd');
      if (tkhd) {
        const tp = pstart(tkhd), tv = tkhd.raw[tp];
        if (tv === 1) w64(tkhd.raw, tp + 28, Math.round(u64(tkhd.raw, tp + 28) * ratio));
        else w32(tkhd.raw, tp + 20, Math.round(u32(tkhd.raw, tp + 20) * ratio));
      }
      const elst = dig(trak, ['edts', 'elst']);
      if (elst) {
        const ep = pstart(elst), ev = elst.raw[ep];
        const count = u32(elst.raw, ep + 4), step = ev === 1 ? 20 : 12;
        for (let i = 0; i < count; i++) {
          const at = ep + 8 + i * step;
          if (ev === 1) w64(elst.raw, at, Math.round(u64(elst.raw, at) * ratio));
          else w32(elst.raw, at, Math.round(u32(elst.raw, at) * ratio));
        }
      }
    }
  }

  /* ---------- sample tables ---------- */
  function chunkTable(trak) {
    const stbl = dig(trak, ['mdia', 'minf', 'stbl']);
    const node = stbl && stbl.kids.find((k) => k.type === 'stco' || k.type === 'co64');
    if (!node) throw new Error('stco/co64 tidak ditemukan.');
    const is64 = node.type === 'co64', p = pstart(node), n = u32(node.raw, p + 4);
    const offsets = new Array(n);
    let o = p + 8;
    for (let i = 0; i < n; i++, o += is64 ? 8 : 4) offsets[i] = is64 ? u64(node.raw, o) : u32(node.raw, o);
    return { is64, offsets };
  }
  function writeChunkTable(trak, offsets, use64) {
    const stbl = dig(trak, ['mdia', 'minf', 'stbl']);
    const idx = stbl.kids.findIndex((k) => k.type === 'stco' || k.type === 'co64');
    const w = use64 ? 8 : 4;
    const payload = new Uint8Array(8 + offsets.length * w);
    w32(payload, 4, offsets.length);
    let o = 8;
    for (const v of offsets) { if (use64) w64(payload, o, v); else w32(payload, o, v); o += w; }
    const type = use64 ? 'co64' : 'stco';
    stbl.kids[idx] = { type, raw: mk(type, payload), kids: null };
  }
  function sampleSizes(trak) {
    const n = dig(trak, ['mdia', 'minf', 'stbl', 'stsz']);
    if (!n) throw new Error('stsz tidak ditemukan.');
    const p = pstart(n), fixed = u32(n.raw, p + 4), count = u32(n.raw, p + 8);
    const sizes = new Array(count);
    if (fixed) sizes.fill(fixed);
    else for (let i = 0, o = p + 12; i < count; i++, o += 4) sizes[i] = u32(n.raw, o);
    return sizes;
  }
  function sampleToChunk(trak) {
    const n = dig(trak, ['mdia', 'minf', 'stbl', 'stsc']);
    if (!n) throw new Error('stsc tidak ditemukan.');
    const p = pstart(n), count = u32(n.raw, p + 4), rows = [];
    for (let i = 0, o = p + 8; i < count; i++, o += 12) rows.push([u32(n.raw, o), u32(n.raw, o + 4)]);
    return rows;
  }
  // posisi absolut [offset, panjang] untuk sampel terakhir sebuah track (di file asli)
  function lastSpans(trak, count) {
    const sizes = sampleSizes(trak), stsc = sampleToChunk(trak), { offsets } = chunkTable(trak);
    const spans = [];
    let s = 0;
    for (let c = 1; c <= offsets.length && s < sizes.length; c++) {
      let perChunk = stsc[0][1];
      for (const r of stsc) if (r[0] <= c) perChunk = r[1];
      let pos = offsets[c - 1];
      for (let j = 0; j < perChunk && s < sizes.length; j++) {
        spans.push([pos, sizes[s]]);
        pos += sizes[s++];
      }
    }
    return spans.slice(-count).sort((a, b) => a[0] - b[0]);
  }

  function makeUdta(text) {
    const data = new TextEncoder().encode(text);
    const dp = new Uint8Array(8 + data.length);
    w32(dp, 0, 1);
    dp.set(data, 8);
    const hp = new Uint8Array(20);
    hp.set(new TextEncoder().encode('mdir'), 8);
    const ilst = mk('ilst', mk('©too', mk('data', dp)));
    return mk('udta', mk('meta', cat([new Uint8Array(4), mk('hdlr', hp), ilst])));
  }
  function mdatHeader(payloadLen) {
    if (8 + payloadLen <= 0xffffffff) { const h = new Uint8Array(8); w32(h, 0, 8 + payloadLen); h.set([0x6d, 0x64, 0x61, 0x74], 4); return h; }
    const h = new Uint8Array(16); w32(h, 0, 1); h.set([0x6d, 0x64, 0x61, 0x74], 4); w64(h, 8, 16 + payloadLen); return h;
  }

  /* ---------- public API ---------- */
  async function readMoov(file) {
    const top = await scanTop(file);
    const m = top.find((b) => b.type === 'moov');
    if (!m) throw new Error('moov tidak ditemukan (bukan MP4/MOV valid).');
    if (m.size > MAX_MOOV) throw new Error('moov terlalu besar.');
    return new Uint8Array(await file.slice(m.offset, m.end).arrayBuffer());
  }

  async function patch(file, opts) {
    const o = Object.assign({ audioTail: true, timescale: 1000, tag: TAG_TEXT, keepUdta: true }, opts || {});
    if (!o.tag) o.tag = TAG_TEXT;
    const top = await scanTop(file);
    const ftyp = top.find((b) => b.type === 'ftyp');
    const moovB = top.find((b) => b.type === 'moov');
    const mdats = top.filter((b) => b.type === 'mdat');
    if (!ftyp || !moovB || mdats.length !== 1) throw new Error('Butuh ftyp, moov, dan tepat satu mdat.');
    if (top.some((b) => b.type === 'moof' || b.type === 'sidx' || b.type === 'mfra')) throw new Error('Fragmented MP4 tidak didukung.');
    if (moovB.size > MAX_MOOV) throw new Error('moov terlalu besar.');
    const mdat = mdats[0];
    const mediaStart = mdat.offset + mdat.hdr;

    const read = async (b) => new Uint8Array(await file.slice(b.offset, b.end).arrayBuffer());
    const ftypBytes = await read(ftyp);
    const moovBytes = await read(moovB);
    const moov = { type: 'moov', raw: null, kids: parseTree(moovBytes, moovB.hdr, moovBytes.length) };

    // sampel audio terakhir (dihitung dari tabel asli, sebelum moov diubah)
    let tail = [];
    const audio = traks(moov).find((t) => handler(t) === 'soun');
    if (o.audioTail && audio) {
      tail = lastSpans(audio, TAIL_COUNT);
      for (const [off, len] of tail) {
        if (off < mediaStart || off + len > mdat.end) throw new Error('Sampel audio di luar mdat.');
      }
    }

    // normalisasi moov
    moov.kids = moov.kids.filter((k) => k.type !== 'meta' && (o.keepUdta || k.type !== 'udta'));
    zeroTimes(moov);
    zeroCompressorName(moov);
    rescaleMovie(moov, o.timescale);
    moov.kids.push({ type: 'udta', raw: makeUdta(o.tag), kids: null });

    // offset chunk
    const tables = traks(moov).map(chunkTable);
    const force64 = tables.some((t) => t.is64) || file.size > 0xffffffff - MAX_MOOV;
    traks(moov).forEach((t, i) => writeChunkTable(t, tables[i].offsets.map(() => 0), force64));
    const sizing = ser(moov).length;

    const free = mk('free', new Uint8Array(0));
    const payloadLen = mdat.end - mediaStart;
    const mh = mdatHeader(payloadLen);
    const shift = ftypBytes.length + sizing + free.length + mh.length - mediaStart;
    traks(moov).forEach((t, i) => writeChunkTable(t, tables[i].offsets.map((v) => v + shift), force64));
    const moovOut = ser(moov);
    if (moovOut.length !== sizing) throw new Error('Ukuran moov berubah saat finalisasi.');

    // susun mdat dari potongan Blob (tanpa menyalin)
    const parts = [ftypBytes, moovOut, free, mh];
    let cur = mediaStart;
    for (const [off, len] of tail) {
      parts.push(file.slice(cur, off));
      const filler = new Uint8Array(len);
      filler.set(TAIL_FILLER.subarray(0, Math.min(len, TAIL_FILLER.length)));
      parts.push(filler);
      cur = off + len;
    }
    parts.push(file.slice(cur, mdat.end));

    return {
      blob: new Blob(parts, { type: 'video/mp4' }),
      report: { faststart: true, timescale: o.timescale, audioTailSamples: tail.length, tag: o.tag, co64: force64 }
    };
  }

  const api = { patch, readMoov, version: '1.3.0' };
  g.NingenCore = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
