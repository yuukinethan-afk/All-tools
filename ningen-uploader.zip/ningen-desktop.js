/*
 * Ningen desktop mode (MAIN world, document_start).
 * Hanya aktif di browser HP (Android/iOS): menyamarkan navigator jadi Chrome Windows dan
 * memaksa viewport 1280 supaya TikTok Studio menampilkan layout desktop. Di PC langsung keluar.
 */
(() => {
  'use strict';
  const realUA = navigator.userAgent || '';
  if (!/Android|iPhone|iPad|iPod|Mobile/i.test(realUA)) return;
  if (window.__ningenDesktop) return;
  window.__ningenDesktop = true;

  const m = realUA.match(/Chrome\/(\d+)/);
  const major = m ? m[1] : '130';
  const full = major + '.0.0.0';
  const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + full + ' Safari/537.36';

  const proto = Object.getPrototypeOf(navigator);
  const def = (prop, val) => {
    try { Object.defineProperty(proto, prop, { get: () => val, configurable: true, enumerable: true }); } catch (_) { /* noop */ }
  };
  def('userAgent', UA);
  def('appVersion', UA.replace('Mozilla/5.0 ', ''));
  def('platform', 'Win32');

  if ('userAgentData' in navigator) {
    const brands = [
      { brand: 'Chromium', version: major },
      { brand: 'Google Chrome', version: major },
      { brand: 'Not=A?Brand', version: '24' }
    ];
    const fullList = brands.map((b) => ({ brand: b.brand, version: b.version === '24' ? '24.0.0.0' : full }));
    def('userAgentData', {
      brands, mobile: false, platform: 'Windows',
      getHighEntropyValues: async () => ({
        brands, mobile: false, platform: 'Windows', platformVersion: '10.0.0',
        architecture: 'x86', bitness: '64', model: '', wow64: false, uaFullVersion: full, fullVersionList: fullList
      }),
      toJSON: () => ({ brands, mobile: false, platform: 'Windows' })
    });
  }

  if (window.top === window) {
    const CONTENT = 'width=1280';
    const ensure = () => {
      const root = document.head || document.documentElement;
      if (!root) return;
      let metas = document.querySelectorAll('meta[name="viewport"]');
      if (!metas.length) {
        const meta = document.createElement('meta');
        meta.name = 'viewport';
        root.appendChild(meta);
        metas = [meta];
      }
      metas.forEach((x) => { if (x.content !== CONTENT) x.content = CONTENT; });
    };
    ensure();
    const obs = new MutationObserver(ensure);
    obs.observe(document, { childList: true, subtree: true, attributes: true, attributeFilter: ['content'] });
    window.addEventListener('load', () => obs.disconnect(), { once: true });
  }
})();
