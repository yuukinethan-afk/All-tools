/*
 * Ningen DNR: di browser HP, ganti header User-Agent untuk tiktok.com ke desktop supaya server
 * mengirim layout TikTok Studio versi desktop. Dipanggil dari popup (tanpa background script,
 * jadi jalan di Chrome, Kiwi, Lemur, Quetta). Di PC aturan dihapus dan tidak ada perubahan.
 */
(function (g) {
  'use strict';
  if (typeof chrome === 'undefined' && typeof browser !== 'undefined') { try { g.chrome = browser; } catch (_) { /* noop */ } }
  const RULE_ID = 9101;
  const isMobile = () => /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '');
  const major = () => { const m = (navigator.userAgent || '').match(/Chrome\/(\d+)/); return m ? m[1] : '130'; };

  function rule(withHints) {
    const ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/' + major() + '.0.0.0 Safari/537.36';
    const headers = [{ header: 'user-agent', operation: 'set', value: ua }];
    if (withHints) {
      headers.push({ header: 'sec-ch-ua-mobile', operation: 'set', value: '?0' });
      headers.push({ header: 'sec-ch-ua-platform', operation: 'set', value: '"Windows"' });
    }
    return {
      id: RULE_ID,
      priority: 1,
      action: { type: 'modifyHeaders', requestHeaders: headers },
      condition: {
        requestDomains: ['tiktok.com'],
        resourceTypes: ['main_frame', 'sub_frame', 'xmlhttprequest', 'script', 'stylesheet', 'other']
      }
    };
  }

  async function ensure() {
    const dnr = g.chrome && chrome.declarativeNetRequest;
    if (!dnr || !dnr.updateDynamicRules) return false;
    try {
      if (!isMobile()) { await dnr.updateDynamicRules({ removeRuleIds: [RULE_ID] }); return false; }
      try {
        await dnr.updateDynamicRules({ removeRuleIds: [RULE_ID], addRules: [rule(true)] });
      } catch (_) {
        await dnr.updateDynamicRules({ removeRuleIds: [RULE_ID], addRules: [rule(false)] }); // sebagian browser menolak sec-ch-ua-*
      }
      return true;
    } catch (e) {
      console.warn('[Ningen] aturan desktop gagal:', e);
      return false;
    }
  }

  g.NingenDNR = { ensure, isMobile };
})(typeof self !== 'undefined' ? self : this);
