/*
 * Ningen hook (MAIN world). Memodifikasi payload posting TikTok Studio:
 *  - normalize: buang draft/canvas_config/vedit_segment_info, jaga sound asli.
 *  - quality  : set flag kualitas tinggi pada request posting (is_high_quality, dll).
 * Tidak menambah caption/mention. Field cover/thumbnail tidak disentuh.
 * Setiap kali payload diubah, hook mengirim pesan ke content script (toast verifikasi) dan,
 * jika log diagnostik aktif, mencetak daftar field yang diubah ke console.
 * Pengaturan datang lewat pesan SETTINGS dari content script (popup).
 */
(() => {
  'use strict';
  if (window.__ningenHook) return;
  window.__ningenHook = true;

  const cfg = { normalize: true, quality: true, debug: false, caption: true, captionText: '✦ Upload Method by Ningen' };
  window.addEventListener('message', (e) => {
    if (e.source !== window) return;
    const d = e.data;
    if (d && d.source === 'NINGEN' && d.type === 'SETTINGS' && d.settings) {
      cfg.normalize = d.settings.normalize !== false;
      cfg.quality = d.settings.quality !== false;
      cfg.debug = d.settings.debug === true;
      cfg.caption = d.settings.caption !== false;
      if (typeof d.settings.captionText === 'string' && d.settings.captionText.trim()) cfg.captionText = d.settings.captionText.trim();
    }
  });

  /* ---------- pengenalan request & payload ---------- */
  const POST_PATH = /(?:\/project\/post|\/publish\/|\/aweme\/v1\/create|\/item\/create)/i;
  const EXACT_POST = 'tiktok/web/project/post/v1/';
  const BLOCKED = /(?:\/music\/|\/sound\/|[?&]music_id=)/i;
  function isPostUrl(u) {
    if (typeof u !== 'string' || !/tiktok/i.test(u)) return false;
    if (u.includes(EXACT_POST)) return true;
    if (BLOCKED.test(u)) return false;
    return POST_PATH.test(u);
  }
  function isPostPayload(p) {
    if (!p || typeof p !== 'object') return false;
    return !!(
      Array.isArray(p.single_post_req_list) || Array.isArray(p.item_list) || Array.isArray(p.text_extra) ||
      p.single_post_feature_info || p.post_common_info || p.item_common_info || p.item_info ||
      p.publish_info || p.post_info || p.enter_post
    );
  }
  const hasSound = (info) => !!(info && info.music_info && (info.music_info.music_id_string || info.music_info.id));

  /* ---------- ubah payload; kembalikan daftar field yang berubah ---------- */
  function apply(p) {
    const log = [];
    if (!isPostPayload(p) || (!cfg.normalize && !cfg.quality && !cfg.caption)) return log;
    const drop = (o, k, where) => { if (o && Object.prototype.hasOwnProperty.call(o, k)) { delete o[k]; log.push('-' + where + k); } };
    const set = (o, k, v, where) => { if (o && o[k] !== v) { o[k] = v; log.push(where + k); } };

    const reqs = Array.isArray(p.single_post_req_list) ? p.single_post_req_list.filter((r) => r && typeof r === 'object') : [];
    const infos = reqs.map((r) => r.single_post_feature_info).filter((i) => i && typeof i === 'object');
    const pci = p.post_common_info && typeof p.post_common_info === 'object' ? p.post_common_info : null;

    if (cfg.caption) {
      const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      const sig = cfg.captionText;
      const addSig = (o, key, markup) => {
        if (!o || typeof o[key] !== 'string') return;
        const cur = o[key];
        const s = markup ? esc(sig) : sig;
        if (cur.indexOf(s) !== -1) return;
        o[key] = cur ? cur.replace(/\s+$/, '') + '\n\n' + s : s;
        log.push((o === p ? '' : 'info.') + key);
      };
      for (const info of infos) {
        if (typeof info.text !== 'string' && typeof info.markup_text !== 'string') info.text = '';
        addSig(info, 'text', false);
        addSig(info, 'markup_text', true);
      }
      if (!infos.length) ['caption', 'desc', 'description', 'text'].forEach((k) => { if (typeof p[k] === 'string' && p[k].length) addSig(p, k, false); });
    }

    if (cfg.normalize) {
      ['draft', 'canvas_config', 'vedit_segment_info'].forEach((k) => drop(p, k, ''));
      set(p, 'cloud_edit_is_use_video_canvas', false, '');
      if (p.enter_post_page_from !== undefined) set(p, 'enter_post_page_from', 1, '');
      if (pci) {
        set(pci, 'post_type', 3, 'post_common_info.');
        set(pci, 'enter_post_page_from', 1, 'post_common_info.');
      }
      if (infos.some(hasSound) && Array.isArray(p.feature_common_info_list)) {
        for (const item of p.feature_common_info_list) {
          const v = item && item.vedit_common_info;
          if (!v || typeof v !== 'object') continue;
          drop(v, 'tiktok_snap_shot_lite_params', 'vedit_common_info.');
          if (Object.prototype.hasOwnProperty.call(v, 'application')) set(v, 'application', 1, 'vedit_common_info.');
        }
      }
      for (const info of infos) {
        drop(info, 'vedit_segment_info', 'info.');
        if (info.cloud_edit_is_use_video_canvas !== undefined) set(info, 'cloud_edit_is_use_video_canvas', false, 'info.');
        set(info, 'has_original_audio', 1, 'info.');
        const m = info.music_info;
        if (m && typeof m === 'object' && !m.music_id_string && m.id) { m.music_id_string = String(m.id); log.push('info.music_info.music_id_string'); }
      }
    }

    if (cfg.quality) {
      set(p, 'psg_vsp_aud', true, '');
      set(p, 'is_high_quality', true, '');
      set(p, 'high_quality_video', 1, '');
      set(p, 'disable_auto_bitrate', true, '');
      if (pci) {
        set(pci, 'psg_vsp_aud', true, 'post_common_info.');
        set(pci, 'is_high_quality', true, 'post_common_info.');
      }
      for (const req of reqs) set(req, 'psg_vsp_aud', true, 'req.');
      for (const info of infos) {
        set(info, 'psg_vsp_aud', true, 'info.');
        set(info, 'video_quality_score', 1.0, 'info.');
        set(info, 'is_high_quality', true, 'info.');
        set(info, 'is_high_quality_video', 1, 'info.');
        set(info, 'upload_high_quality', true, 'info.');
        set(info, 'disable_auto_bitrate', true, 'info.');
        set(info, 'video_fps', 144, 'info.');
        set(info, 'source_fps', 144, 'info.');
      }
    }
    return log;
  }

  function notify(where, log) {
    if (!log.length) return;
    if (cfg.debug) { try { console.log('[Ningen] payload diubah via ' + where + ' (' + log.length + ' field):', log.join(', ')); } catch (_) { /* noop */ } }
    try { window.postMessage({ source: 'NINGEN_HOOK', type: 'PATCHED', count: log.length, where }, '*'); } catch (_) { /* noop */ }
  }

  function rewrite(body, where) {
    if (typeof body !== 'string' || !body) return body;
    try {
      const obj = JSON.parse(body);
      const log = apply(obj);
      if (!log.length) return body;
      notify(where, log);
      return JSON.stringify(obj);
    } catch (_) { return body; }
  }

  // Jaga-jaga jika TikTok membangun body lewat jalur lain: cek objek post saat di-stringify.
  const nativeStringify = JSON.stringify;
  JSON.stringify = function (value, replacer, space) {
    try { if (isPostPayload(value)) notify('JSON.stringify', apply(value)); } catch (_) { /* noop */ }
    return nativeStringify.call(this, value, replacer, space);
  };

  const nativeFetch = window.fetch;
  if (typeof nativeFetch === 'function') {
    window.fetch = async function (input, init) {
      try {
        const url = typeof input === 'string' ? input : (input && input.url) || '';
        if (isPostUrl(url)) {
          if (init && typeof init.body === 'string') {
            init = Object.assign({}, init, { body: rewrite(init.body, 'fetch') });
          } else if (typeof Request !== 'undefined' && input instanceof Request && !(init && init.body)) {
            const m = String(input.method || 'GET').toUpperCase();
            if (m !== 'GET' && m !== 'HEAD') {
              const text = await input.clone().text();
              const next = rewrite(text, 'fetch(Request)');
              if (next !== text) input = new Request(input, { body: next });
            }
          }
        }
      } catch (_) { /* biarkan request asli lewat */ }
      return nativeFetch.call(this, input, init);
    };
  }

  const xhr = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
  if (xhr) {
    const open = xhr.open, send = xhr.send;
    xhr.open = function (method, url) { this.__ningenUrl = String(url || ''); return open.apply(this, arguments); };
    xhr.send = function (body) {
      try { if (isPostUrl(this.__ningenUrl) && typeof body === 'string') body = rewrite(body, 'xhr'); } catch (_) { /* noop */ }
      return send.call(this, body);
    };
  }
})();
