/* Ningen meta: pembaca info video (resolusi, fps, bitrate, codec) dari box moov. Lokal. */
(function (g) {
  'use strict';
  const AVC = { 66: 'Baseline', 77: 'Main', 88: 'Extended', 100: 'High', 110: 'High 10', 122: 'High 4:2:2', 244: 'High 4:4:4' };
  const HEVC = { 1: 'Main', 2: 'Main 10', 3: 'Main Still' };

  function parse(moovBytes) {
    const b = moovBytes;
    const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
    const t4 = (o) => String.fromCharCode(b[o], b[o + 1], b[o + 2], b[o + 3]);
    function* boxes(s, e) {
      let o = s;
      while (o + 8 <= e) {
        let size = dv.getUint32(o), hdr = 8;
        const t = t4(o + 4);
        if (size === 1) { if (o + 16 > e) return; size = Number(dv.getBigUint64(o + 8)); hdr = 16; }
        else if (size === 0) size = e - o;
        if (size < hdr) return;
        if (o + size > e) size = e - o;
        yield { t, s: o + hdr, e: o + size };
        o += size;
      }
    }
    const find = (box, t) => { if (!box) return null; for (const x of boxes(box.s, box.e)) if (x.t === t) return x; return null; };

    const moov = find({ s: 0, e: b.length }, 'moov');
    if (!moov) throw new Error('moov tidak ditemukan');

    for (const trak of boxes(moov.s, moov.e)) {
      if (trak.t !== 'trak') continue;
      const mdia = find(trak, 'mdia');
      const hdlr = find(mdia, 'hdlr');
      if (!hdlr || t4(hdlr.s + 8) !== 'vide') continue;

      const out = { w: 0, h: 0, fps: 0, bitrate: 0, codecKey: '', codec: '—', seconds: 0 };

      const tkhd = find(trak, 'tkhd');
      if (tkhd) {
        const end = tkhd.e;
        out.w = Math.round(dv.getUint32(end - 8) / 65536);
        out.h = Math.round(dv.getUint32(end - 4) / 65536);
      }

      const mdhd = find(mdia, 'mdhd');
      let ts = 0, dur = 0;
      if (mdhd) {
        if (b[mdhd.s] === 1) { ts = dv.getUint32(mdhd.s + 20); dur = Number(dv.getBigUint64(mdhd.s + 24)); }
        else { ts = dv.getUint32(mdhd.s + 12); dur = dv.getUint32(mdhd.s + 16); }
      }
      out.seconds = ts ? dur / ts : 0;

      const stbl = find(find(mdia, 'minf'), 'stbl');

      const stsz = find(stbl, 'stsz');
      let frames = 0, bytes = 0;
      if (stsz) {
        const fixed = dv.getUint32(stsz.s + 4);
        frames = dv.getUint32(stsz.s + 8);
        if (fixed) bytes = fixed * frames;
        else for (let i = 0, o = stsz.s + 12; i < frames && o + 4 <= stsz.e; i++, o += 4) bytes += dv.getUint32(o);
      }
      if (out.seconds > 0) {
        out.fps = frames / out.seconds;
        out.bitrate = (bytes * 8) / out.seconds;
      }

      const stsd = find(stbl, 'stsd');
      if (stsd) {
        const entry = stsd.s + 8;
        const type = t4(entry + 4);
        const kids = entry + 8 + 78;
        const entryEnd = entry + dv.getUint32(entry);
        const label = type.toLowerCase();
        if (/^avc[13]$/.test(label)) {
          out.codecKey = 'avc';
          const c = find({ s: kids, e: entryEnd }, 'avcC');
          out.codec = 'H.264/AVC';
          if (c) out.codec += ' ' + (AVC[b[c.s + 1]] || 'Profile ' + b[c.s + 1]) + ' L' + (b[c.s + 3] / 10).toFixed(1);
        } else if (/^h(vc|ev)1$/.test(label)) {
          out.codecKey = 'hevc';
          const c = find({ s: kids, e: entryEnd }, 'hvcC');
          out.codec = 'H.265/HEVC';
          if (c) out.codec += ' ' + (HEVC[b[c.s + 1] & 31] || '');
        } else {
          out.codecKey = label;
          out.codec = type;
        }
      }
      return out;
    }
    throw new Error('track video tidak ditemukan');
  }

  const fmt = {
    res: (m) => (m && m.w ? m.w + '×' + m.h : '—'),
    fps: (m) => (m && m.fps ? (Math.round(m.fps * 100) / 100).toString() : '—'),
    size: (n) => (n >= 1073741824 ? (n / 1073741824).toFixed(2) + ' GB' : (n / 1048576).toFixed(1) + ' MB'),
    bitrate: (m) => (m && m.bitrate ? (m.bitrate / 1e6).toFixed(1) + ' Mbps' : '—')
  };

  g.NingenMeta = { parse, fmt };
})(typeof globalThis !== 'undefined' ? globalThis : this);
