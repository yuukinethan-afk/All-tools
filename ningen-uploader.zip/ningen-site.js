/* Penanda untuk web tools: situs bisa tahu ekstensi Ningen sudah terpasang. Hanya menulis atribut versi. */
(() => {
  'use strict';
  try {
    const v = chrome.runtime.getManifest().version;
    document.documentElement.setAttribute('data-ningen', v);
    window.addEventListener('message', (e) => {
      if (e.source === window && e.data && e.data.type === 'NINGEN_PING') window.postMessage({ type: 'NINGEN_PONG', version: v }, '*');
    });
  } catch (_) { /* noop */ }
})();
