NINGEN UPLOADER v1.7.1
Ekstensi Chrome/Edge/Kiwi/Quetta untuk TikTok Studio. Video MP4 di-patch lokal di browser
sebelum diunggah, supaya TikTok tidak mengompres ulang. Tidak ada data yang dikirim keluar.

PASANG
1. Ekstrak ZIP.
2. Buka chrome://extensions, aktifkan Developer mode.
3. Load unpacked, pilih folder hasil ekstrak.
   (Android: Kiwi/Quetta/Lemur -> Developer mode -> pasang dari .zip)

PAKAI
1. Buka popup, tekan "UPLOAD METHOD NINGEN" (membuka TikTok Studio, mode desktop otomatis di HP).
2. Di halaman upload, pilih video lewat kartu Ningen. Video di-patch otomatis lalu diteruskan ke TikTok.
3. Isi caption seperti biasa. Teks "Upload Method by Ningen" ditambahkan di akhir caption.

PENGATURAN (popup -> Lanjutan)
- Watermark caption + teks watermark
- Rapikan payload posting
- Flag kualitas tinggi
- Mode agresif (filler audio, menimpa 4 sampel audio terakhir)
- Log diagnostik (cetak field yang diubah ke console)
- Tag metadata video (default @asepfrimawan)

MODE ADMIN (opsional)
Buat kode lewat admin.html -> panel "Kode Mode Admin (Ningen)". Tempel kodenya di popup Lanjutan -> Kode admin.
Instalasi itu lalu SELALU aktif walau saklar jarak jauh dimatikan untuk pengguna lain. Kode dicek ke server
tiap ±10 menit (bukan dicocokkan di dalam ekstensi), jadi bisa kamu cabut kapan saja dari admin.html tanpa
update ekstensi. Kalau server tak terjangkau, status terakhir yang diketahui tetap dipakai sementara.

SAKLAR JARAK JAUH (opsional)
Ekstensi mengecek /api/ningen-kill di web tools kamu tiap ±10 menit. Kalau dimatikan dari admin, SEMUA
fitur patch (MP4, payload posting, watermark caption) nonaktif di semua browser yang terpasang; video
dikirim apa adanya seperti tanpa ekstensi. Kalau server tak terjangkau, ekstensi tetap aktif (default ON),
jadi tidak terkunci kalau servernya sedang mati.

WEB TOOLS (popup)
Daftar tool dari server web tools (https://alltoolsningen.vercel.app): lima tool bawaan + tool tambahan dari
/api/tools (admin). Ketuk untuk membuka di tab baru; tool VIP dibuka lewat situs (kunci dicek di sana).
Satu-satunya koneksi keluar ekstensi selain TikTok: GET /api/tools untuk membaca daftar (hanya data, tanpa kode).
Offline: memakai daftar bawaan / cache terakhir.

VIDEO LATAR
- bglaunch.mp4 : latar tombol Upload Method Ningen (popup)
- bg.mp4       : latar kartu di halaman upload TikTok Studio
- compare.mp4  : opsional, bagian "lihat perbedaannya" di tab app
Rasio sekitar 2,9:1 (1570x540), H.264, tanpa suara. Tanpa file, latar gradasi dipakai.

CATATAN
- Hanya MP4/MOV (H.264/HEVC). Fragmented MP4 dan file di atas 4 GB tidak diproses; file asli dikirim apa adanya.
- Hasil di TikTok tidak bisa dijamin; platform dapat mengubah perilakunya sewaktu-waktu.
