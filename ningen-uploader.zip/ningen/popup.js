if (typeof chrome === 'undefined' && typeof browser !== 'undefined') { try { globalThis.chrome = browser; } catch (e) { /* noop */ } }
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const STUDIO_URL = 'https://www.tiktok.com/tiktokstudio/upload?from=upload';
  const TXT = {
    id: {
      subtitle: 'Ekstensi untuk mencegah video TikTok kamu dikompresi',
      launch: 'UPLOAD METHOD NINGEN', menu: 'MENU', newtab: 'BUKA DI TAB BARU',
      on: 'UPLOADER AKTIF', off: 'UPLOADER MATI',
      hint: 'Saat AKTIF, video di-patch otomatis di TikTok Studio.',
      adv: 'LANJUTAN',
      capL: 'Watermark caption', capH: 'Tambah teks di akhir caption posting', capTL: 'Teks watermark',
      hookL: 'Rapikan payload posting', hookH: 'Jaga sound asli, tanpa caption tambahan',
      qualL: 'Flag kualitas tinggi', qualH: 'Set is_high_quality dkk di request posting',
      tailL: 'Mode agresif (filler audio)', tailH: 'Menimpa 4 sampel audio terakhir',
      dbgL: 'Log diagnostik', dbgH: 'Cetak field yang diubah ke console halaman',
      tagL: 'Tag metadata video (©too)',
      cmpLabel: 'BANDINGKAN', cmpTitle: 'LIHAT PERBEDAANNYA', cmpSub: 'video sama, kualitas lebih baik',
      toolsL: 'WEB TOOLS', site: 'BUKA SEMUA TOOLS',
      admL: 'Kode admin (abaikan saklar jarak jauh)', admOn: 'Mode admin aktif — kebal saklar jarak jauh', admOff: 'Kode salah / kosong',
      killOff: 'Dinonaktifkan dari server', killAdmin: 'Dinonaktifkan untuk pengguna lain — mode admin kamu tetap kebal', killChk: 'Cek ulang sekarang', killChking: 'Mengecek…', 
      local: '100% LOKAL'
    },
    en: {
      subtitle: 'An extension to prevent your TikTok videos from being compressed',
      launch: 'UPLOAD METHOD NINGEN', menu: 'MENU', newtab: 'OPEN IN NEW TAB',
      on: 'UPLOADER ON', off: 'UPLOADER OFF',
      hint: 'When ON, videos are patched automatically in TikTok Studio.',
      adv: 'ADVANCED',
      capL: 'Caption watermark', capH: 'Append text to the end of the post caption', capTL: 'Watermark text',
      hookL: 'Clean up post payload', hookH: 'Keeps original sound, no extra caption',
      qualL: 'High-quality flags', qualH: 'Sets is_high_quality etc. in the post request',
      tailL: 'Aggressive mode (audio filler)', tailH: 'Overwrites the last 4 audio samples',
      dbgL: 'Diagnostic log', dbgH: 'Print changed fields to the page console',
      tagL: 'Video metadata tag (©too)',
      cmpLabel: 'COMPARE', cmpTitle: 'SEE THE DIFFERENCE', cmpSub: 'same video, better quality',
      toolsL: 'WEB TOOLS', site: 'OPEN ALL TOOLS',
      admL: 'Admin key (bypass remote kill switch)', admOn: 'Admin mode active — immune to remote switch', admOff: 'Wrong / empty key',
      killOff: 'Disabled from server', killAdmin: 'Disabled for other users — your admin mode stays immune', killChk: 'Check again now', killChking: 'Checking…', 
      local: '100% LOCAL'
    }
  };

  const store = chrome.storage.local;
  const DEFAULTS = { ningenLang: null, ningenOn: true, ningenHook: true, ningenQuality: true, ningenTail: true, ningenTag: '@asepfrimawan', ningenDebug: false, ningenCaption: true, ningenCaptionText: '✦ Upload Method by Ningen', ningenAdminKey: '' };
  const ADMIN_VERIFY_URL = 'https://alltoolsningen.vercel.app/api/ningen-admin';
  const KILL_URL = 'https://alltoolsningen.vercel.app/api/ningen-kill';
  let killOn = true, killMsg = '';
  function fetchKillNow() {
    return fetch(KILL_URL, { cache: 'no-store', credentials: 'omit' }).then((r2) => (r2.ok ? r2.json() : null)).then((d) => {
      if (!d || typeof d.on !== 'boolean') return;
      killOn = d.on; killMsg = d.msg || ''; render();
      store.set({ ningenRemoteCache: { on: d.on, msg: d.msg, ts: Date.now() } });
    });
  }
  function checkKillStatus() {
    // Pakai cache yang sama dengan content script (ningenRemoteCache) biar tidak dobel nembak server; tetap fetch kalau cache kosong/basi.
    store.get({ ningenRemoteCache: null }, (r) => {
      const c = r.ningenRemoteCache;
      if (c && typeof c.on === 'boolean') { killOn = c.on; killMsg = c.msg || ''; render(); }
      if (c && Date.now() - (c.ts || 0) < 10 * 60 * 1000) return;
      fetchKillNow().catch(() => { /* offline: pakai cache/default */ });
    });
  }
  let adminOk = null;
  // Verifikasi ke server (bukan hash lokal), supaya status di popup sama persis dengan yang dipakai ekstensi.
  async function checkAdminKey(key) {
    key = (key || '').trim();
    if (!key) { adminOk = null; render(); return; }
    try {
      const r = await fetch(ADMIN_VERIFY_URL, { method: 'POST', cache: 'no-store', credentials: 'omit', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'verify', key }) });
      const d = r.ok ? await r.json() : null;
      if (d && typeof d.ok === 'boolean') adminOk = d.ok;
    } catch (_) { /* offline: biarkan status sebelumnya */ }
    render();
  }
  let lang = /^id/i.test(navigator.language || '') ? 'id' : 'en';
  let on = true;
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };

  function render() {
    const t = TXT[lang];
    document.documentElement.lang = lang;
    set('subtitle', t.subtitle); set('launchText', t.launch); set('menuLabel', t.menu); set('hint', t.hint);
    set('newTabText', t.newtab); set('patcherText', on ? t.on : t.off); set('advLabel', t.adv);
    set('tCapLabel', t.capL); set('tCapHint', t.capH); set('tCapTextLabel', t.capTL);
    set('toolsLabel', t.toolsL); set('siteText', t.site);
    set('tHookLabel', t.hookL); set('tHookHint', t.hookH);
    set('tQualLabel', t.qualL); set('tQualHint', t.qualH);
    set('tTailLabel', t.tailL); set('tTailHint', t.tailH);
    set('tDbgLabel', t.dbgL); set('tDbgHint', t.dbgH);
    set('tTagLabel', t.tagL); set('tAdmLabel', t.admL); set('localTxt', t.local);
    const st = $('tAdmStat'); if (st) { st.textContent = adminOk === null ? '' : (adminOk ? t.admOn : t.admOff); st.classList.toggle('on', !!adminOk); }
    const kh = $('killHint');
    if (kh) {
      if (killOn === false) {
        kh.hidden = false; kh.classList.add('kill');
        kh.textContent = (adminOk ? '✓ ' + t.killAdmin : '⛔ ' + t.killOff) + (killMsg ? ': ' + killMsg : '.');
      } else { kh.hidden = true; kh.classList.remove('kill'); }
    }
    const kr = $('killRefresh'); if (kr) { kr.hidden = killOn !== false; set('killRefreshText', t.killChk); }
    set('compareLabel', t.cmpLabel); set('cmpTitle', t.cmpTitle); set('cmpSub', t.cmpSub);
    $('patcherBtn').classList.toggle('on', on);
    $('patcherBtn').setAttribute('aria-pressed', String(on));
    $('langEn').classList.toggle('active', lang === 'en');
    $('langId').classList.toggle('active', lang === 'id');
  }

  checkKillStatus();
  store.get(DEFAULTS, (r) => {
    lang = r.ningenLang || lang;
    if (!r.ningenLang) store.set({ ningenLang: lang });
    on = r.ningenOn !== false;
    $('tHook').checked = r.ningenHook !== false;
    $('tQual').checked = r.ningenQuality !== false;
    $('tTail').checked = r.ningenTail !== false;
    $('tDbg').checked = r.ningenDebug === true;
    $('tCap').checked = r.ningenCaption !== false;
    $('tCapText').value = (typeof r.ningenCaptionText === 'string' && r.ningenCaptionText) || '✦ Upload Method by Ningen';
    $('tTag').value = (typeof r.ningenTag === 'string' && r.ningenTag) || '@asepfrimawan';
    $('tAdm').value = (typeof r.ningenAdminKey === 'string' && r.ningenAdminKey) || '';
    checkAdminKey($('tAdm').value);
    render();
  });
  render();

  try { if (globalThis.NingenDNR) NingenDNR.ensure(); } catch (e) { /* noop */ }

  $('langEn').onclick = () => { lang = 'en'; store.set({ ningenLang: lang }); render(); };
  $('langId').onclick = () => { lang = 'id'; store.set({ ningenLang: lang }); render(); };
  $('patcherBtn').onclick = () => { on = !on; store.set({ ningenOn: on }); render(); };
  $('tHook').onchange = (e) => store.set({ ningenHook: e.target.checked });
  $('tQual').onchange = (e) => store.set({ ningenQuality: e.target.checked });
  $('tTail').onchange = (e) => store.set({ ningenTail: e.target.checked });
  $('tDbg').onchange = (e) => store.set({ ningenDebug: e.target.checked });
  $('tCap').onchange = (e) => store.set({ ningenCaption: e.target.checked });
  $('tCapText').onchange = (e) => store.set({ ningenCaptionText: e.target.value.trim() || '✦ Upload Method by Ningen' });
  $('tTag').onchange = (e) => store.set({ ningenTag: e.target.value.trim() || '@asepfrimawan' });
  $('tAdm').onchange = (e) => { const v = e.target.value.trim(); store.set({ ningenAdminKey: v }); checkAdminKey(v); };
  $('launchBtn').onclick = async () => {
    // nyalakan desktop mode dulu (HP), baru buka TikTok Studio
    try { await NingenDNR.ensure(); } catch (e) { /* noop */ }
    chrome.tabs.create({ url: STUDIO_URL });
  };
  $('newTabBtn').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });
  const krBtn = $('killRefresh');
  if (krBtn) krBtn.onclick = () => { set('killRefreshText', TXT[lang].killChking); krBtn.disabled = true; fetchKillNow().catch(() => {}).then(() => { krBtn.disabled = false; render(); }); };

  /* ---------- Web Tools: daftar bawaan + sinkron dari server (hanya link, tidak ada kode dijalankan) ---------- */
  const SITE = 'https://alltoolsningen.vercel.app/';
  const BUILTIN = [
    { id: 'am-unlocker', n: 'AM Unlocker', d: 'Buka premium Alight Motion via magic link.', b: 'VIP', vip: true },
    { id: 'tt-dl', n: 'TikTok Downloader', d: 'Unduh video TikTok tanpa watermark, sekalian audionya (MP3).', b: 'TIKTOK' },
    { id: 'pin-dl', n: 'Pinterest Downloader', d: 'Unduh video dari pin Pinterest, tinggal tempel link.', b: 'PINTEREST' },
    { id: 'temail', n: 'Email Sementara', d: 'Alamat email sekali pakai buat terima kode verifikasi.', b: 'TEMP' },
    { id: 'finder-preset', n: 'Finder Preset', d: 'Tempel link TikTok edit, temukan link preset dari caption dan komentar.', b: 'TIKTOK', u: 'https://ningen-finder-preset.vercel.app/' }
  ];
  const okUrl = (u) => /^https?:\/\/[^\s'"()<>\\]+$/i.test(String(u || ''));
  const okBg = (b) => okUrl(b) || /^(linear|radial)-gradient\([a-zA-Z0-9#%.,()\s-]+\)$/.test(String(b || ''));
  function openUrl(u) { chrome.tabs.create({ url: u }); }
  function renderTools(list) {
    const box = $('toolsList'); if (!box) return;
    box.textContent = '';
    list.forEach((t) => {
      const el = document.createElement('button');
      el.type = 'button'; el.className = 'tool';
      const bg = t.bg && okBg(t.bg) ? t.bg : '';
      if (bg) { el.classList.add('has-bg'); el.style.backgroundImage = /^https?:/i.test(bg) ? 'url("' + bg + '")' : bg; }
      const n = document.createElement('b'); n.textContent = String(t.n || '').slice(0, 60);
      const d = document.createElement('small'); d.textContent = String(t.d || '').slice(0, 140);
      const bd = document.createElement('span'); bd.className = 'bd' + (t.vip ? ' vip' : ''); bd.textContent = t.vip ? 'VIP' : String(t.b || 'LINK').slice(0, 12);
      el.append(n, d, bd);
      // tool VIP dibuka lewat situs (kunci VIP dicek di sana); tool dengan link langsung dibuka apa adanya
      el.onclick = () => openUrl(!t.vip && okUrl(t.u) ? t.u : SITE + '#' + encodeURIComponent(t.id));
      box.appendChild(el);
    });
  }
  function mergeTools(d) {
    const a = Array.isArray(d) ? d : (d && d.tools) || [];
    const ov = (!Array.isArray(d) && d && d.over) || {};
    const base = BUILTIN.map((t) => Object.assign({}, t));
    base.forEach((t) => { const o = ov[t.id]; if (!o) return; if (o.n) t.n = o.n; if (o.bg) t.bg = o.bg; if (o.vip !== undefined) t.vip = !!o.vip; });
    const kept = base.filter((t) => !(ov[t.id] && ov[t.id].hide));
    const custom = a.filter((x) => x && x.n).map((x) => ({ id: 'c-' + x.id, n: x.n, d: x.d, b: x.b, u: x.u, bg: x.bg, vip: !!x.vip }));
    return kept.concat(custom);
  }
  renderTools(BUILTIN);
  store.get({ ningenToolsCache: null }, (r) => { if (r.ningenToolsCache) renderTools(mergeTools(r.ningenToolsCache)); });
  try {
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 6000);
    fetch(SITE + 'api/tools', { cache: 'no-store', signal: ctl.signal })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { clearTimeout(to); if (d && typeof d === 'object') { renderTools(mergeTools(d)); store.set({ ningenToolsCache: d }); } })
      .catch(() => { /* offline: pakai daftar bawaan/cache */ });
  } catch (e) { /* noop */ }
  $('siteBtn').onclick = () => openUrl(SITE);

  /* video latar opsional (bglaunch.mp4, compare.mp4): tanpa file, latar CSS dipakai / bagian disembunyikan */
  const bg = document.querySelector('.launch-bg');
  if (bg) {
    const dim = document.querySelector('.launch-dim');
    const drop = () => { bg.remove(); if (dim) dim.remove(); };
    bg.addEventListener('error', drop, { once: true });
    bg.addEventListener('loadeddata', () => { const fx = document.querySelector('.launch-fx'); if (fx) fx.remove(); const p = bg.play(); if (p && p.catch) p.catch(() => {}); }, { once: true });
    document.addEventListener('visibilitychange', () => { if (document.hidden) bg.pause(); else { const p = bg.play(); if (p && p.catch) p.catch(() => {}); } });
  }
  const cmp = $('cmpVideo');
  if (cmp) {
    cmp.addEventListener('loadeddata', () => { $('compareSec').hidden = false; const p = cmp.play(); if (p && p.catch) p.catch(() => {}); }, { once: true });
    cmp.addEventListener('error', () => { $('compareSec').hidden = true; }, { once: true });
  }
})();
