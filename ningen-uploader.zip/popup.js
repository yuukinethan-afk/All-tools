if (typeof chrome === 'undefined' && typeof browser !== 'undefined') { try { globalThis.chrome = browser; } catch (e) { /* noop */ } }
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const STUDIO_URL = 'https://www.tiktok.com/tiktokstudio/upload?from=upload';
  const TIKTOK_DEV_URL = 'https://www.tiktok.com/@asepfrimawan';
  const WA_URL = 'https://whatsapp.com/channel/0029VbBNSiJJ93watcQasK2F';
  const TXT = {
    id: {
      subtitle: 'Extension untuk tetap pada Video Original',
      launch: 'UPLOAD METHOD NINGEN', menu: 'MENU', newtab: 'BUKA DI TAB BARU',
      hint: 'Video di-patch otomatis saat kamu pilih di TikTok Studio.',
      adv: 'SETTING',
      capTL: 'Teks watermark caption (selalu aktif)',
      hookL: 'Rapikan payload posting', hookH: 'Jaga sound asli, tanpa caption tambahan',
      qualL: 'Flag kualitas tinggi', qualH: 'Set is_high_quality dkk di request posting',
      tailL: 'Mode agresif (filler audio)', tailH: 'Menimpa 4 sampel audio terakhir',
      dbgL: 'Log diagnostik', dbgH: 'Cetak field yang diubah ke console halaman',
      tagL: 'Tag metadata video (©too)',
      cmpLabel: 'BANDINGKAN', cmpTitle: 'LIHAT PERBEDAANNYA', cmpSub: 'video sama, kualitas lebih baik',
      contactL: 'KONTAK DEVELOPER', ctWa: 'WHATSAPP CHANNEL',
      admL: 'Kode admin (abaikan saklar jarak jauh)', admOn: 'Mode admin aktif — kebal saklar jarak jauh', admOff: 'Kode salah / kosong',
      admOutdated: 'Ekstensi belum versi terbaru — update dulu',
      killTitle: 'Server Nonaktif', killMsgDefault: 'Fitur Ningen sedang dimatikan sementara dari server. Video dikirim apa adanya ke TikTok.',
      outdatedTitle: 'Perlu Update', outdatedMsgDefault: 'Versi ekstensi ini sudah lama. Update ke versi terbaru dulu supaya Ningen bisa dipakai lagi.',
      local: '100% LOKAL'
    },
    en: {
      subtitle: 'Extension to keep your Video Original',
      launch: 'UPLOAD METHOD NINGEN', menu: 'MENU', newtab: 'OPEN IN NEW TAB',
      hint: 'Videos are patched automatically when selected in TikTok Studio.',
      adv: 'SETTING',
      capTL: 'Caption watermark text (always on)',
      hookL: 'Clean up post payload', hookH: 'Keeps original sound, no extra caption',
      qualL: 'High-quality flags', qualH: 'Sets is_high_quality etc. in the post request',
      tailL: 'Aggressive mode (audio filler)', tailH: 'Overwrites the last 4 audio samples',
      dbgL: 'Diagnostic log', dbgH: 'Print changed fields to the page console',
      tagL: 'Video metadata tag (©too)',
      cmpLabel: 'COMPARE', cmpTitle: 'SEE THE DIFFERENCE', cmpSub: 'same video, better quality',
      contactL: 'DEVELOPER CONTACT', ctWa: 'WHATSAPP CHANNEL',
      admL: 'Admin key (bypass remote kill switch)', admOn: 'Admin mode active — immune to remote switch', admOff: 'Wrong / empty key',
      admOutdated: 'Extension is outdated — update first',
      killTitle: 'Server Disabled', killMsgDefault: 'Ningen is temporarily disabled from the server. Videos are sent as-is to TikTok.',
      outdatedTitle: 'Update Required', outdatedMsgDefault: 'This extension version is outdated. Update to the latest version to use Ningen again.',
      local: '100% LOCAL'
    }
  };

  const store = chrome.storage.local;
  const DEFAULTS = { ningenLang: null, ningenHook: true, ningenQuality: true, ningenTail: true, ningenTag: '@asepfrimawan', ningenDebug: false, ningenCaptionText: '✦ Upload Method by Ningen', ningenAdminKey: '' };
  const ADMIN_VERIFY_URL = 'https://alltoolsningen.vercel.app/api/ningen-admin';
  const KILL_URL = 'https://alltoolsningen.vercel.app/api/ningen-kill';
  const EXT_VERSION = (chrome.runtime.getManifest && chrome.runtime.getManifest().version) || '0.0.0';
  // Bandingkan versi semver sederhana "1.8.0" vs "1.7.4". Return true kalau `a` lebih lama dari `b`.
  function versionBehind(a, b) {
    const pa = String(a || '0').split('.').map((n) => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const x = pa[i] || 0, y = pb[i] || 0;
      if (x < y) return true;
      if (x > y) return false;
    }
    return false;
  }
  let killOn = true, killMsg = '', outdated = false;
  function applyKillData(d) {
    killOn = d.on !== false; killMsg = d.msg || '';
    const lv = String(d.latestVersion || '').trim();
    // Versi ekstensi di bawah "versi terbaru" yang diset admin: KUNCI TOTAL untuk SEMUA orang,
    // termasuk yang punya kode admin — bukan cuma kode admin-nya yang ditolak.
    outdated = !!lv && versionBehind(EXT_VERSION, lv);
    render();
  }
  function fetchKillNow() {
    return fetch(KILL_URL, { cache: 'no-store', credentials: 'omit' }).then((r2) => (r2.ok ? r2.json() : null)).then((d) => {
      if (!d || typeof d.on !== 'boolean') return;
      applyKillData(d);
      store.set({ ningenRemoteCache: { on: d.on, msg: d.msg, latestVersion: d.latestVersion, ts: Date.now() } });
    });
  }
  function checkKillStatus() {
    // Pakai cache yang sama dengan content script (ningenRemoteCache) biar tidak dobel nembak server; tetap fetch kalau cache kosong/basi.
    store.get({ ningenRemoteCache: null }, (r) => {
      const c = r.ningenRemoteCache;
      if (c && typeof c.on === 'boolean') applyKillData(c);
      if (c && Date.now() - (c.ts || 0) < 20 * 1000) return;
      fetchKillNow().catch(() => { /* offline: pakai cache/default */ });
    });
  }
  // adminOk: null (belum dicek), true (kode valid + ekstensi versi terbaru), false (salah/kosong/ekstensi usang)
  let adminOk = null, adminOutdated = false;
  // Verifikasi ke server (bukan hash lokal) sekaligus kirim versi ekstensi, supaya kode admin
  // hanya berlaku bila ekstensi sudah versi terbaru (server yang memutuskan, bukan client).
  async function checkAdminKey(key) {
    key = (key || '').trim();
    if (!key) { adminOk = null; adminOutdated = false; render(); return; }
    try {
      const r = await fetch(ADMIN_VERIFY_URL, {
        method: 'POST', cache: 'no-store', credentials: 'omit', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify', key, version: EXT_VERSION }),
      });
      const d = r.ok ? await r.json() : null;
      if (d && typeof d.ok === 'boolean') { adminOk = d.ok; adminOutdated = !!d.outdated; }
    } catch (_) { /* offline: biarkan status sebelumnya */ }
    render();
  }
  let lang = /^id/i.test(navigator.language || '') ? 'id' : 'en';
  const set = (id, v) => { const el = $(id); if (el) el.textContent = v; };

  function render() {
    const t = TXT[lang];
    document.documentElement.lang = lang;
    set('subtitle', t.subtitle); set('launchText', t.launch); set('menuLabel', t.menu); set('hint', t.hint);
    set('newTabText', t.newtab); set('advLabel', t.adv);
    set('tCapTextLabel', t.capTL);
    set('tHookLabel', t.hookL); set('tHookHint', t.hookH);
    set('tQualLabel', t.qualL); set('tQualHint', t.qualH);
    set('tTailLabel', t.tailL); set('tTailHint', t.tailH);
    set('tDbgLabel', t.dbgL); set('tDbgHint', t.dbgH);
    set('tTagLabel', t.tagL); set('tAdmLabel', t.admL); set('localTxt', t.local);
    set('contactLabel', t.contactL); set('ctWaText', t.ctWa);
    const st = $('tAdmStat');
    if (st) {
      st.textContent = adminOk === null ? '' : (adminOk ? t.admOn : (adminOutdated ? t.admOutdated : t.admOff));
      st.classList.toggle('on', !!adminOk);
    }
    set('compareLabel', t.cmpLabel); set('cmpTitle', t.cmpTitle); set('cmpSub', t.cmpSub);
    $('langEn').classList.toggle('active', lang === 'en');
    $('langId').classList.toggle('active', lang === 'id');

    const modal = $('killModal');
    if (modal) {
      // Outdated mengunci TOTAL (tidak ada yang kebal, termasuk kode admin). Kalau tidak outdated,
      // baru saklar on/off server yang berlaku (dan itu yang bisa dibypass kode admin valid).
      const show = outdated || (killOn === false && !adminOk);
      modal.hidden = !show;
      if (outdated) { set('killTitle', t.outdatedTitle); set('killMsgText', t.outdatedMsgDefault); }
      else if (show) { set('killTitle', t.killTitle); set('killMsgText', killMsg || t.killMsgDefault); }
    }
  }

  checkKillStatus();
  store.get(DEFAULTS, (r) => {
    lang = r.ningenLang || lang;
    if (!r.ningenLang) store.set({ ningenLang: lang });
    $('tHook').checked = r.ningenHook !== false;
    $('tQual').checked = r.ningenQuality !== false;
    $('tTail').checked = r.ningenTail !== false;
    $('tDbg').checked = r.ningenDebug === true;
    $('tCapText').value = (typeof r.ningenCaptionText === 'string' && r.ningenCaptionText) || '✦ Upload Method by Ningen';
    $('tTag').value = (typeof r.ningenTag === 'string' && r.ningenTag) || '@asepfrimawan';
    $('tAdm').value = (typeof r.ningenAdminKey === 'string' && r.ningenAdminKey) || '';
    checkAdminKey($('tAdm').value);
    render();
  });
  render();

  try { if (globalThis.NingenDNR) NingenDNR.ensure(); } catch (e) { /* noop */ }

  $('langEn').onclick = () => { lang = 'en'; store.set({ ningenLang: lang }); render(); };
  $('langId').onclick = () => { lang = 'id'; store.set({ ningenLang: lang }); render(); };
  $('tHook').onchange = (e) => store.set({ ningenHook: e.target.checked });
  $('tQual').onchange = (e) => store.set({ ningenQuality: e.target.checked });
  $('tTail').onchange = (e) => store.set({ ningenTail: e.target.checked });
  $('tDbg').onchange = (e) => store.set({ ningenDebug: e.target.checked });
  $('tCapText').onchange = (e) => store.set({ ningenCaptionText: e.target.value.trim() || '✦ Upload Method by Ningen' });
  $('tTag').onchange = (e) => store.set({ ningenTag: e.target.value.trim() || '@asepfrimawan' });
  $('tAdm').onchange = (e) => { const v = e.target.value.trim(); store.set({ ningenAdminKey: v }); checkAdminKey(v); };
  $('launchBtn').onclick = async () => {
    // nyalakan desktop mode dulu (HP), baru buka TikTok Studio
    try { await NingenDNR.ensure(); } catch (e) { /* noop */ }
    chrome.tabs.create({ url: STUDIO_URL });
  };
  $('newTabBtn').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('app.html') });

  /* ---------- kontak developer ---------- */
  $('ctTiktok').onclick = () => chrome.tabs.create({ url: TIKTOK_DEV_URL });
  $('ctWa').onclick = () => chrome.tabs.create({ url: WA_URL });

  /* video latar opsional (body.mp4, bglaunch.mp4, compare.mp4): tanpa file, latar CSS dipakai / bagian disembunyikan */
  const bodyBg = document.querySelector('.body-bg');
  if (bodyBg) {
    const dim = document.querySelector('.body-dim');
    bodyBg.addEventListener('error', () => { bodyBg.remove(); if (dim) dim.style.background = 'var(--bg)'; }, { once: true });
    bodyBg.addEventListener('loadeddata', () => { const p = bodyBg.play(); if (p && p.catch) p.catch(() => {}); }, { once: true });
    document.addEventListener('visibilitychange', () => { if (document.hidden) bodyBg.pause(); else { const p = bodyBg.play(); if (p && p.catch) p.catch(() => {}); } });
  }
  const bg = document.querySelector('.launch-bg');
  if (bg) {
    const dim = document.querySelector('.launch-dim');
    const drop = () => { bg.remove(); if (dim) dim.remove(); };
    bg.addEventListener('error', drop, { once: true });
    bg.addEventListener('loadeddata', () => { const fx = document.querySelector('.launch-fx'); if (fx) fx.remove(); const p = bg.play(); if (p && p.catch) p.catch(() => {}); }, { once: true });
    document.addEventListener('visibilitychange', () => { if (document.hidden) bg.pause(); else { const p = bg.play(); if (p && p.catch) p.catch(() => {}); } });
  }
  const cmp = $('cmpVideo');
  if (cmp) {
    cmp.addEventListener('loadeddata', () => { $('compareSec').hidden = false; const p = cmp.play(); if (p && p.catch) p.catch(() => {}); }, { once: true });
    cmp.addEventListener('error', () => { $('compareSec').hidden = true; }, { once: true });
  }
})();
